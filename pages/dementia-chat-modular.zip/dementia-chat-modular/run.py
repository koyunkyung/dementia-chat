# -*- coding: utf-8 -*-
# 실행 엔트리포인트
from main import chat_loop

if __name__ == "__main__":
    chat_loop()